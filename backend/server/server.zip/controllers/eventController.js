/* eslint-disable camelcase */
const Event = require('../models/Event')
// const User = require('../models/User')

// Create a new sevice
module.exports.addEvent_post = async (req, res) => {
  const { title, body, location, start_date, end_date, status, user_id } = req.body
  const picture = req.file ? req.file.path : ''
  // const user = await User.findOne({
  //   where: { email }
  // })
  // const user_id = user.id
  try {
    const event = await Event.create({ title, body, picture, location, start_date, end_date, status, user_id })
    res.status(201).json(event)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

// get all sevices
module.exports.allEvent_get = async (req, res) => {
  try {
    const events = await Event.findAll()
    res.status(200).json({ events })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

// Get a specific event by slug
module.exports.event_get = async (req, res) => {
  const { slug } = req.params
  try {
    const event = await Event.findOne({
      where: { slug }
    })
    if (!event) {
      return res.status(404).json({ error: 'Event not found' })
    }
    res.status(200).json({ event })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

// Update a specific event
module.exports.updateEvent_post = async (req, res) => {
  const eventId = req.params.id
  const updatedEvent = req.body

  try {
    const event = await Event.findByPk(eventId)
    if (event) {
      if (req.file) {
        event.picture = req.file.path
      }
      Object.assign(event, updatedEvent)
      event.updatedAt = new Date()
      await event.save()
      res.status(200).json({ event })
    } else {
      res.status(404).json({ error: 'Event not found' })
    }
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
}

// Delete a specific event
module.exports.deleteEvent_post = async (req, res) => {
  const eventId = req.params.id

  try {
    const event = await Event.findByPk(eventId)
    if (event) {
      await event.destroy()
      res.status(200).json({ message: 'Event deleted successfully' })
    } else {
      res.status(404).json({ error: 'Event not found' })
    }
  } catch (err) {
    res.status(400).json({ error: err.message })
  }
}
