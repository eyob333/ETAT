/* eslint-disable camelcase */
const JobApplication = require('../models/jobApplication')
const Job = require('../models/Job')

// Create a new sevice
module.exports.addJobApplication_post = async (req, res) => {
  const {
    name,
    address,
    phone,
    email,
    field_of_study,
    gpa,
    name_of_previous_company,
    total_years_of_experience,
    available_start_date,
    cover_letter,
    expected_salary,
    prospectus_confirmation
  } = req.body
  const { job_id } = req.params
  const resume = req.file ? req.file.path : ''

  const job = await Job.findByPk(job_id)
  if (!job) {
    return res.status(404).json({ error: 'Referenced job not found' })
  }

  try {
    const jobApplication = await JobApplication.create({
      name,
      address,
      phone,
      email,
      field_of_study,
      gpa,
      name_of_previous_company,
      total_years_of_experience,
      available_start_date,
      resume,
      cover_letter,
      expected_salary,
      prospectus_confirmation,
      job_id
    })
    res.status(201).json(jobApplication)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

// get all sevices
module.exports.allJobApplication_get = async (req, res) => {
  try {
    const jobApplications = await JobApplication.findAll()
    res.status(200).json({ jobApplications })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

// Get a specific jobApplication by ID
module.exports.jobApplication_get = async (req, res) => {
  const { job_id } = req.params
  try {
    const jobApplication = await JobApplication.findAll({
      where: { job_id }
    })

    if (!jobApplication) {
      return res.status(404).json({ error: 'Job application not found' })
    }
    res.status(200).json({ jobApplication })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}
