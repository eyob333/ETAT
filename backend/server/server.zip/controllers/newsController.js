/* eslint-disable camelcase */
const News = require('../models/News')
const User = require('../models/User')

// Create a new news
module.exports.addNews_post = async (req, res) => {
  const { title, body, author_name, email } = req.body
  const picture = req.file ? req.file.path : ''
  try {
    const user = await User.findOne({
      where: { email }
    })
    const user_id = user.id
    const news = await News.create({ title, body, picture, author_name, user_id })
    res.status(201).json(news)
  } catch (error) {
    console.log(error)
    res.status(500).json({ error: error.message })
  }
}

// get all news
module.exports.allNews_get = async (req, res) => {
  try {
    const news = await News.findAll()
    res.status(200).json({ news })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

// Get a specific news by slug
module.exports.news_get = async (req, res) => {
  const { slug } = req.params
  try {
    const news = await News.findOne({
      where: { slug }
    })
    if (!news) {
      return res.status(404).json({ error: 'News not found' })
    }
    res.status(200).json({ news })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

// Update a specific news
module.exports.updateNews_post = async (req, res) => {
  const newsId = req.params.id
  const updatedNews = req.body

  try {
    const news = await News.findByPk(newsId)
    if (news) {
      Object.assign(news, updatedNews)

      if (req.file) {
        news.picture = req.file.path
      }
      news.updatedAt = new Date()
      await news.save()
      res.status(200).json({ news })
    } else {
      res.status(404).json({ error: 'News not found' })
    }
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
}

// Delete a specific news
module.exports.deleteNews_post = async (req, res) => {
  const newsId = req.params.id

  try {
    const news = await News.findByPk(newsId)
    if (news) {
      await news.destroy()
      res.status(200).json({ message: 'News deleted successfully' })
    } else {
      res.status(404).json({ error: 'News not found' })
    }
  } catch (err) {
    res.status(400).json({ error: err.message })
  }
}
