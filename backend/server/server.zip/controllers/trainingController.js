/* eslint-disable camelcase */
const Training = require('../models/Training')
const User = require('../models/User')

// Create a new sevice
module.exports.addTraining_post = async (req, res) => {
  const { title, body, author_name, email } = req.body
  const picture = req.file ? req.file.path : ''
  try {
    const user = await User.findOne({
      where: { email }
    })
    const user_id = user.id
    const training = await Training.create({ title, body, author_name, picture, user_id })
    res.status(201).json(training)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

// get all sevices
module.exports.allTraining_get = async (req, res) => {
  try {
    const trainings = await Training.findAll()
    res.status(200).json({ trainings })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

// Get a specific training by ID
module.exports.training_get = async (req, res) => {
  const { slug } = req.params
  try {
    const training = await Training.findOne({
      where: { slug }
    })
    if (!training) {
      return res.status(404).json({ error: 'Training not found' })
    }
    res.status(200).json({ training })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

// Update a specific training
module.exports.updateTraining_post = async (req, res) => {
  const trainingId = req.params.id
  const updatedTraining = req.body

  try {
    const training = await Training.findByPk(trainingId)
    if (training) {
      if (req.file) {
        training.picture = req.file.path
      }
      Object.assign(training, updatedTraining)

      training.updatedAt = new Date()
      await training.save()
      res.status(200).json({ training })
    } else {
      res.status(404).json({ error: 'Training not found' })
    }
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
}

// Delete a specific training
module.exports.deleteTraining_post = async (req, res) => {
  const trainingId = req.params.id

  try {
    const training = await Training.findByPk(trainingId)
    if (training) {
      await training.destroy()
      res.status(200).json({ message: 'Training deleted successfully' })
    } else {
      res.status(404).json({ error: 'Training not found' })
    }
  } catch (err) {
    res.status(400).json({ error: err.message })
  }
}
