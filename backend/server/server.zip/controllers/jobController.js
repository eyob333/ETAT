/* eslint-disable camelcase */
const Job = require('../models/Job')
const User = require('../models/User')

// Create a new sevice
module.exports.addJob_post = async (req, res) => {
  const { title, body, company, location, department, employment_type, workplace_type, compansation, salary, start_date, end_date, email } = req.body

  const picture = req.file ? req.file.path : ''
  const user = await User.findOne({
    where: { email }
  })
  const user_id = user.id
  try {
    const job = await Job.create({
      title,
      body,
      company,
      location,
      department,
      employment_type,
      workplace_type,
      compansation,
      salary,
      start_date,
      end_date,
      picture,
      user_id
    })
    res.status(201).json(job)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

// get all sevices
module.exports.allJob_get = async (req, res) => {
  try {
    const jobs = await Job.findAll()
    res.status(200).json({ jobs })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

// Get a specific job by slug
module.exports.job_get = async (req, res) => {
  const { slug } = req.params
  try {
    const job = await Job.findOne({
      where: { slug }
    })
    if (!job) {
      return res.status(404).json({ error: 'Job not found' })
    }
    res.status(200).json({ job })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
}

// Update a specific job
module.exports.updateJob_post = async (req, res) => {
  const jobId = req.params.id
  const updatedJob = req.body
  try {
    const job = await Job.findByPk(jobId)
    if (job) {
      Object.assign(job, updatedJob)

      if (req.file) {
        job.picture = req.file.path
      }
      job.updatedAt = new Date()
      await job.save()
      res.status(200).json({ job })
    } else {
      res.status(404).json({ error: 'Job not found' })
    }
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
}

// Delete a specific job
module.exports.deleteJob_post = async (req, res) => {
  const jobId = req.params.id

  try {
    const job = await Job.findByPk(jobId)
    if (job) {
      await job.destroy()
      res.status(200).json({ message: 'Job deleted successfully' })
    } else {
      res.status(404).json({ error: 'Job not found' })
    }
  } catch (err) {
    res.status(400).json({ error: err.message })
  }
}
