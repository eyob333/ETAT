module.exports = {
  HOST: 'localhost',
  USER: 'postgres',
  PORT: 5432,
  PASSWORD: '1234',
  DATABASE: 'ethiotech',
  DIALECT: 'postgres'
}
