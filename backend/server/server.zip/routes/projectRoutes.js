const { Router } = require('express')
const projectController = require('../controllers/projectController')
const verifyJWT = require('../middleware/verifyJWT')
const verifyAdmin = require('../middleware/verifyAdmin')
const upload = require('../middleware/fileUpload')
const apicache = require('apicache')

const router = Router()

// Init cache
const cache = apicache.middleware

router.get('/projects', cache('2 minutes'), projectController.allProject_get)
router.get('/projects/:id', cache('2 minutes'), projectController.project_get)

router.post('/projects', verifyJWT, verifyAdmin, upload.single('image'), projectController.addProject_post)
router.patch('/projects/:id', verifyJWT, verifyAdmin, upload.single('image'), projectController.updateProject_post)
router.delete('/projects/:id', verifyJWT, verifyAdmin, projectController.deleteProject_post)

module.exports = router
