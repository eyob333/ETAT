require('dotenv').config()

module.exports = {
  HOST: process.env.HOST,
  USER: process.env.USER,
  PORT: process.env.PORT,
  PASSWORD: process.env.DB_PASSWORD,
  DATABASE: process.env.DB,
  DIALECT: 'postgres'
}